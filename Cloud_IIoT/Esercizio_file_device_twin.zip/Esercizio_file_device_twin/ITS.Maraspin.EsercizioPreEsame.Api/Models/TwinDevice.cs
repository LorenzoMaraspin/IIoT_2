﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITS.Maraspin.EsercizioPreEsame.Api.Models
{
    public class TwinDevice
    {
        public string Desired { get; set; }
    }
}
