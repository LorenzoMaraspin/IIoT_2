﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITS.Maraspin.EsercizioPreEsame.Application.Models
{
    public class FileModelReceive
    {
        public string FileName { get; set; }
        public string Message { get; set; }
    }
}
