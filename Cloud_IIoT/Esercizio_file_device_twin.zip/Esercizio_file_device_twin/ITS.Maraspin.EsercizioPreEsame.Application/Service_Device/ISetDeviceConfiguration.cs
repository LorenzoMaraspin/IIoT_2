﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITS.Maraspin.EsercizioPreEsame.Application.Service_Device
{
    public interface ISetDeviceConfiguration
    {
        void SetDeviceDesired(string filename);
    }
}
